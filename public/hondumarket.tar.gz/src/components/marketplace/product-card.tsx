'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Heart, ShoppingCart, Eye, Star } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'

interface ProductCardProps {
  id: string
  title: string
  price: number
  originalPrice?: number
  images?: string[]
  thumbnail?: string
  condition: string
  views: number
  favoritesCount: number
  category: string
  seller: {
    name: string
    rating: number
  }
  isAuction?: boolean
  auctionEndDate?: Date
  currentBid?: number
}

export function ProductCard({
  id,
  title,
  price,
  originalPrice,
  images,
  thumbnail,
  condition,
  views,
  favoritesCount,
  category,
  seller,
  isAuction,
  auctionEndDate,
  currentBid
}: ProductCardProps) {
  const imageUrl = thumbnail || (images && JSON.parse(images)[0]) || '/placeholder-product.svg'
  const discount = originalPrice ? Math.round(((originalPrice - price) / originalPrice) * 100) : 0

  const formatPrice = (amount: number) => {
    return new Intl.NumberFormat('es-HN', {
      style: 'currency',
      currency: 'HNL'
    }).format(amount)
  }

  const getConditionText = (condition: string) => {
    switch (condition) {
      case 'NEW': return 'Nuevo'
      case 'USED': return 'Usado'
      case 'REFURBISHED': return 'Reacondicionado'
      default: return condition
    }
  }

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'NEW': return 'bg-green-100 text-green-800'
      case 'USED': return 'bg-orange-100 text-orange-800'
      case 'REFURBISHED': return 'bg-blue-100 text-blue-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <Card className="group hover:shadow-lg transition-shadow duration-200">
      <CardContent className="p-0">
        {/* Imagen del producto */}
        <div className="relative overflow-hidden rounded-t-lg">
          <Link href={`/producto/${id}`}>
            <div className="aspect-square relative">
              <Image
                src={imageUrl}
                alt={title}
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-200"
              />
            </div>
          </Link>
          
          {/* Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {discount > 0 && (
              <Badge className="bg-red-500 text-white">
                -{discount}%
              </Badge>
            )}
            <Badge className={getConditionColor(condition)}>
              {getConditionText(condition)}
            </Badge>
            {isAuction && (
              <Badge className="bg-purple-500 text-white">
                Subasta
              </Badge>
            )}
          </div>

          {/* Botón de favoritos */}
          <Button
            size="sm"
            variant="ghost"
            className="absolute top-2 right-2 bg-white/80 hover:bg-white text-gray-600 hover:text-red-500"
          >
            <Heart className="h-4 w-4" />
          </Button>
        </div>

        {/* Información del producto */}
        <div className="p-4">
          <div className="mb-2">
            <Badge variant="outline" className="text-xs">
              {category}
            </Badge>
          </div>

          <Link href={`/producto/${id}`}>
            <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2 hover:text-blue-600 transition-colors">
              {title}
            </h3>
          </Link>

          {/* Precio */}
          <div className="mb-3">
            {isAuction ? (
              <div>
                <p className="text-sm text-gray-500">Puja actual</p>
                <p className="text-xl font-bold text-purple-600">
                  {formatPrice(currentBid || price)}
                </p>
                {auctionEndDate && (
                  <p className="text-xs text-gray-500">
                    Termina: {new Date(auctionEndDate).toLocaleDateString('es-HN')}
                  </p>
                )}
              </div>
            ) : (
              <div>
                <p className="text-xl font-bold text-gray-900">
                  {formatPrice(price)}
                </p>
                {originalPrice && originalPrice > price && (
                  <p className="text-sm text-gray-500 line-through">
                    {formatPrice(originalPrice)}
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Información del vendedor */}
          <div className="flex items-center justify-between mb-3 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
              <span>{seller.rating.toFixed(1)}</span>
              <span>{seller.name}</span>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1">
                <Eye className="h-3 w-3" />
                <span>{views}</span>
              </div>
              <div className="flex items-center gap-1">
                <Heart className="h-3 w-3" />
                <span>{favoritesCount}</span>
              </div>
            </div>
          </div>

          {/* Botones de acción */}
          <div className="flex gap-2">
            <Button
              size="sm"
              className="flex-1"
              onClick={() => {/* Lógica para añadir al carrito */}}
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              {isAuction ? 'Pujar' : 'Comprar'}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {/* Lógica para favoritos */}}
            >
              <Heart className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}