import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Obtener un producto por ID
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const product = await db.product.findUnique({
      where: { id: params.id },
      include: {
        seller: {
          select: {
            id: true,
            name: true,
            email: true,
            rating: true,
            salesCount: true,
            createdAt: true
          }
        },
        category: {
          select: {
            id: true,
            name: true,
            description: true
          }
        },
        reviews: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true
              }
            }
          },
          orderBy: {
            createdAt: 'desc'
          }
        },
        _count: {
          select: {
            favorites: true,
            reviews: true
          }
        }
      }
    })

    if (!product) {
      return NextResponse.json(
        { error: 'Producto no encontrado' },
        { status: 404 }
      )
    }

    // Incrementar contador de vistas
    await db.product.update({
      where: { id: params.id },
      data: {
        views: {
          increment: 1
        }
      }
    })

    return NextResponse.json({ product })

  } catch (error) {
    console.error('Error obteniendo producto:', error)
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

// PUT - Actualizar un producto
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    
    // Verificar si el producto existe
    const existingProduct = await db.product.findUnique({
      where: { id: params.id }
    })

    if (!existingProduct) {
      return NextResponse.json(
        { error: 'Producto no encontrado' },
        { status: 404 }
      )
    }

    // TODO: Verificar si el usuario es el vendedor del producto

    // Actualizar producto
    const product = await db.product.update({
      where: { id: params.id },
      data: {
        title: body.title,
        description: body.description,
        price: body.price,
        originalPrice: body.originalPrice,
        condition: body.condition,
        stock: body.stock,
        categoryId: body.categoryId,
        images: body.images ? JSON.stringify(body.images) : existingProduct.images,
        tags: body.tags ? JSON.stringify(body.tags) : existingProduct.tags,
        status: body.status
      },
      include: {
        seller: {
          select: {
            id: true,
            name: true,
            rating: true
          }
        },
        category: {
          select: {
            id: true,
            name: true
          }
        }
      }
    })

    return NextResponse.json({
      message: 'Producto actualizado exitosamente',
      product
    })

  } catch (error) {
    console.error('Error actualizando producto:', error)
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

// DELETE - Eliminar un producto
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Verificar si el producto existe
    const existingProduct = await db.product.findUnique({
      where: { id: params.id }
    })

    if (!existingProduct) {
      return NextResponse.json(
        { error: 'Producto no encontrado' },
        { status: 404 }
      )
    }

    // TODO: Verificar si el usuario es el vendedor del producto

    // Eliminar producto (cambiar status a INACTIVE en lugar de eliminar)
    await db.product.update({
      where: { id: params.id },
      data: {
        status: 'INACTIVE'
      }
    })

    return NextResponse.json({
      message: 'Producto eliminado exitosamente'
    })

  } catch (error) {
    console.error('Error eliminando producto:', error)
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}