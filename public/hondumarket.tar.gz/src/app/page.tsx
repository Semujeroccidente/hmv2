'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/marketplace/header'
import { ProductCard } from '@/components/marketplace/product-card'
import { AuctionCard } from '@/components/marketplace/auction-card'
import { SearchFilters } from '@/components/marketplace/search-filters'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Carousel, 
  CarouselContent, 
  CarouselItem, 
  CarouselNext, 
  CarouselPrevious 
} from '@/components/ui/carousel'
import { 
  Star, 
  TrendingUp, 
  Users, 
  ShoppingBag, 
  ArrowRight,
  Zap,
  Shield,
  Heart,
  Gavel
} from 'lucide-react'

export default function Home() {
  const [user, setUser] = useState(null)
  const [products, setProducts] = useState([])
  const [auctions, setAuctions] = useState([])
  const [categories] = useState([
    { id: '1', name: 'Electrónica', icon: '📱' },
    { id: '2', name: 'Ropa y Accesorios', icon: '👕' },
    { id: '3', name: 'Hogar y Jardín', icon: '🏠' },
    { id: '4', name: 'Vehículos', icon: '🚗' },
    { id: '5', name: 'Propiedades', icon: '🏢' },
    { id: '6', name: 'Servicios', icon: '💼' }
  ])

  useEffect(() => {
    // Verificar si hay un usuario logueado
    const checkAuth = async () => {
      try {
        const response = await fetch('/api/auth/me')
        if (response.ok) {
          const data = await response.json()
          setUser(data.user)
        }
      } catch (error) {
        console.error('Error checking auth:', error)
      }
    }

    // Cargar productos destacados
    const loadProducts = async () => {
      try {
        const response = await fetch('/api/products?limit=4&sortBy=createdAt&sortOrder=desc')
        if (response.ok) {
          const data = await response.json()
          setProducts(data.products)
        } else {
          // Usar datos de ejemplo como fallback
          const sampleProducts = [
            {
              id: '1',
              title: 'iPhone 13 Pro Max - Excelente Estado',
              price: 25000,
              originalPrice: 30000,
              condition: 'USED',
              views: 245,
              favoritesCount: 18,
              category: 'Electrónica',
              seller: {
                name: 'Juan Pérez',
                rating: 4.8
              },
              thumbnail: '/placeholder-product.svg'
            },
            {
              id: '2',
              title: 'Laptop Dell Inspiron 15',
              price: 18000,
              condition: 'NEW',
              views: 132,
              favoritesCount: 7,
              category: 'Electrónica',
              seller: {
                name: 'María González',
                rating: 4.9
              },
              thumbnail: '/placeholder-product.svg'
            },
            {
              id: '3',
              title: 'Zapatillas Nike Air Max - Nuevas',
              price: 3500,
              originalPrice: 4500,
              condition: 'NEW',
              views: 89,
              favoritesCount: 12,
              category: 'Ropa y Accesorios',
              seller: {
                name: 'Carlos Rodríguez',
                rating: 4.7
              },
              thumbnail: '/placeholder-product.svg'
            },
            {
              id: '4',
              title: 'Sofá de 3 Plazas - Cuero Genuino',
              price: 12000,
              condition: 'REFURBISHED',
              views: 167,
              favoritesCount: 9,
              category: 'Hogar y Jardín',
              seller: {
                name: 'Ana Martínez',
                rating: 4.6
              },
              thumbnail: '/placeholder-product.svg'
            }
          ]
          setProducts(sampleProducts)
        }
      } catch (error) {
        console.error('Error loading products:', error)
        // Usar datos de ejemplo como fallback
        const sampleProducts = [
          {
            id: '1',
            title: 'iPhone 13 Pro Max - Excelente Estado',
            price: 25000,
            originalPrice: 30000,
            condition: 'USED',
            views: 245,
            favoritesCount: 18,
            category: 'Electrónica',
            seller: {
              name: 'Juan Pérez',
              rating: 4.8
            },
            thumbnail: '/placeholder-product.svg'
          }
        ]
        setProducts(sampleProducts)
      }
    }

    // Cargar subastas activas
    const loadAuctions = async () => {
      try {
        // Datos de ejemplo mientras tanto
        const sampleAuctions = [
          {
            id: '1',
            title: 'MacBook Pro M1 2020',
            startingPrice: 15000,
            currentPrice: 18500,
            endDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 días
            status: 'ACTIVE',
            bidCount: 12,
            seller: {
              name: 'TechStore HN',
              rating: 4.9
            },
            product: {
              id: '1',
              title: 'MacBook Pro M1 2020',
              condition: 'USED',
              thumbnail: '/placeholder-product.svg'
            }
          },
          {
            id: '2',
            title: 'PlayStation 5 + 2 Controles',
            startingPrice: 8000,
            currentPrice: 9200,
            endDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 días
            status: 'ACTIVE',
            bidCount: 8,
            seller: {
              name: 'GamerZone',
              rating: 4.8
            },
            product: {
              id: '2',
              title: 'PlayStation 5 + 2 Controles',
              condition: 'NEW',
              thumbnail: '/placeholder-product.svg'
            }
          }
        ]
        setAuctions(sampleAuctions)
      } catch (error) {
        console.error('Error loading auctions:', error)
      }
    }

    checkAuth()
    loadProducts()
    loadAuctions()
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      <Header user={user} />
      
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Bienvenido a HonduraMarket
              </h1>
              <p className="text-xl md:text-2xl mb-8 text-blue-100">
                El marketplace más grande de Honduras. Compra, vende y participa en subastas de forma segura.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                  <ShoppingBag className="mr-2 h-5 w-5" />
                  Comprar ahora
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                  <Gavel className="mr-2 h-5 w-5" />
                  Ver subastas
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Estadísticas */}
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="flex justify-center mb-2">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900">10,000+</div>
                <div className="text-gray-600">Usuarios activos</div>
              </div>
              <div className="text-center">
                <div className="flex justify-center mb-2">
                  <ShoppingBag className="h-8 w-8 text-green-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900">5,000+</div>
                <div className="text-gray-600">Productos</div>
              </div>
              <div className="text-center">
                <div className="flex justify-center mb-2">
                  <Gavel className="h-8 w-8 text-purple-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900">500+</div>
                <div className="text-gray-600">Subastas activas</div>
              </div>
              <div className="text-center">
                <div className="flex justify-center mb-2">
                  <Star className="h-8 w-8 text-yellow-500" />
                </div>
                <div className="text-3xl font-bold text-gray-900">4.8</div>
                <div className="text-gray-600">Calificación promedio</div>
              </div>
            </div>
          </div>
        </section>

        {/* Categorías */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-8">Explorar categorías</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {categories.map((category) => (
                <Card key={category.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl mb-2">{category.icon}</div>
                    <h3 className="font-medium">{category.name}</h3>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Productos y Subastas */}
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <Tabs defaultValue="products" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-8">
                <TabsTrigger value="products">Productos destacados</TabsTrigger>
                <TabsTrigger value="auctions">Subastas activas</TabsTrigger>
              </TabsList>
              
              <TabsContent value="products">
                <div className="mb-8">
                  <h2 className="text-2xl font-bold mb-6">Productos destacados</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {products.map((product) => (
                      <ProductCard key={product.id} {...product} />
                    ))}
                  </div>
                  <div className="text-center mt-8">
                    <Button variant="outline" size="lg">
                      Ver todos los productos
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="auctions">
                <div className="mb-8">
                  <h2 className="text-2xl font-bold mb-6">Subastas activas</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {auctions.map((auction) => (
                      <AuctionCard key={auction.id} {...auction} />
                    ))}
                  </div>
                  <div className="text-center mt-8">
                    <Button variant="outline" size="lg">
                      Ver todas las subastas
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Características */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">¿Por qué elegir HonduraMarket?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex justify-center mb-4">
                    <Shield className="h-12 w-12 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Compras seguras</h3>
                  <p className="text-gray-600">
                    Protección en todas tus transacciones y sistema de calificación de vendedores.
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex justify-center mb-4">
                    <Zap className="h-12 w-12 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Rápido y fácil</h3>
                  <p className="text-gray-600">
                    Interfaz intuitiva diseñada para la mejor experiencia de compra y venta.
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="flex justify-center mb-4">
                    <Heart className="h-12 w-12 text-red-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Hecho para Honduras</h3>
                  <p className="text-gray-600">
                    Plataforma local adaptada a las necesidades del mercado hondureño.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 bg-blue-600 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">¿Listo para empezar?</h2>
            <p className="text-xl mb-8 text-blue-100">
              Únete a miles de hondureños que ya compran y venden en nuestra plataforma.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                Registrarse gratis
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                Cómo funciona
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <ShoppingBag className="h-5 w-5 text-white" />
                </div>
                <span className="text-xl font-bold">HonduraMarket</span>
              </div>
              <p className="text-gray-400">
                El marketplace más grande de Honduras.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Comprar</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Todos los productos</a></li>
                <li><a href="#" className="hover:text-white">Categorías</a></li>
                <li><a href="#" className="hover:text-white">Subastas</a></li>
                <li><a href="#" className="hover:text-white">Ofertas</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Vender</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Cómo vender</a></li>
                <li><a href="#" className="hover:text-white">Tarifas</a></li>
                <li><a href="#" className="hover:text-white">Para empresas</a></li>
                <li><a href="#" className="hover:text-white">Éxito de vendedores</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Ayuda</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Centro de ayuda</a></li>
                <li><a href="#" className="hover:text-white">Contacto</a></li>
                <li><a href="#" className="hover:text-white">Términos y condiciones</a></li>
                <li><a href="#" className="hover:text-white">Privacidad</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 HonduraMarket. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}